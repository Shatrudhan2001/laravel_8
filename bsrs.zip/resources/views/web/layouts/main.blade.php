@include('web.layouts.header')
@yield('main.container')
@include('web.layouts.footer')
