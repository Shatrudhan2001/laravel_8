 <?php $__env->startSection('main.container'); ?>
    <!-- Container Start -->
    <div class="page-wrapper">
        <div class="main-content">
            <!-- Page Title Start -->
            <div class="row">
                <div class="col xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="page-title-wrapper">
                        <div class="page-title-box">
                            <h4 class="page-title"><?php echo e($title); ?></h4>
                        </div>
                        <div class="breadcrumb-list">
                            <ul>
                                <li class="breadcrumb-link">
                                    <a href="<?php echo e(url('/dashboard')); ?>"><i class="fas fa-home mr-2"></i>Dashboard</a>
                                </li>
                                <li class="breadcrumb-link active"><?php echo e($title); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="from-wrapper">
                <div class="row">
                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <div class="row">
                                    <div style="border: 1px solid; padding: 10px; margin-right: 20px;">
                                        <p><b>Name :</b> <?php echo e($memberData->name); ?></p>
                                        <p><b>Email :</b> <?php echo e($memberData->email); ?></p>
                                        <p><b>Mobile :</b> <?php echo e($memberData->phone); ?></p>
                                    
                                    </div>
                                    <a href="<?php echo e(url('ToPayment/'.$member_id)); ?>" class="btn btn-success btn-sm" style="float: right;"> To Pay <a>
                                </div>
                            </div>
                            <div class="card-body">
                                
                                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="alert alert-danger mb-2 col-lg-6 offset-3 text-center"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> 
                                    <?php if(session('status')): ?>
                                        <div class="alert alert-success mb-2 col-lg-6 offset-3 text-center">
                                            <?php echo e(session('status')); ?>

                                        </div>
                                    <?php endif; ?>

                                    <div class="chart-holder">
                                        <div class="table-responsive">
                                            <table class="table table-styled mb-0">
                                                <thead>
                                                    <tr>
                                                      <th scope="col">S.No</th>
                                                      <th scope="col">Month</th>
                                                      <th scope="col">Opening Balance</th>
                                                      <th scope="col">Monthly Subscription</th>
                                                      <th scope="col">Amount Paid</th>
                                                      <th scope="col">Closing Balance</th>
                                                      <th scope="col">Mode of Payment</th>
                                                      <th scope="col">Payment Date</th>
                                                    </tr>
                                                  </thead>
                                                  <tbody>
                                                    <?php if(!empty($data)): ?>
                                                        <?php $i = 1; ?>
                                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $date = date_create($r->created_on); ?>
                                                            <tr>
                                                              <th scope="row"><?= $i++; ?></th>
                                                              <td style="width:120px"><?= date_format($date,"d-F"); ?></td>
                                                              <td><?php echo e($r->opening_balance); ?></td>
                                                              <td><?php echo e($r->subscriptions); ?></td>
                                                              <td><?php echo e($r->amount); ?></td>
                                                              <td><?php echo e($r->closing_balance); ?></td>
                                                              <td><?php echo e($r->payment_mode); ?></td>
                                                              <td><?php echo e($r->created_on); ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>
                                                  </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Products view Start -->
            <?php $__env->stopSection(); ?>
        </div>
    </div>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsrs/public_html/demo/resources/views/admin/payment-history.blade.php ENDPATH**/ ?>