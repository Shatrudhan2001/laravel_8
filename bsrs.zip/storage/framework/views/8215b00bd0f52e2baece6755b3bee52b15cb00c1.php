<?php echo $__env->make('web.member.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main.container'); ?>
<?php echo $__env->make('web.member.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /home/bsrs/public_html/resources/views/web/member/layouts/main.blade.php ENDPATH**/ ?>