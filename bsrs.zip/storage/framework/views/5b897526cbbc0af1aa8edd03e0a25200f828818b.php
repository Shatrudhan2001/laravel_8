
<?php $__env->startSection('main.container'); ?>
    <!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(url('web/images/background/2.jpg')); ?>)">
        <div class="auto-container">
            <h1><?php echo e($title); ?></h1>
            <ul class="page-breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><?php echo e($title); ?></li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
   <section class="about-section">
       
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                   <div class="faq-form">
                     
                     <!-- Contact Form -->
                    <?php if(session('status')): ?>
                        <div class="alert alert-success text-center">
                            <b><?php echo e(session('status')); ?></b>
                        </div>
                     <?php endif; ?>
                     <h3 class="text-center">Donation Form</h3>
                     <form method="post" action="<?php echo e(url('donate')); ?>" id="formData">
                     <?php echo csrf_field(); ?>
                        <div class="row clearfix">
                        
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" id="name" name="name" placeholder="Your Name*" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>">
                              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="email" name="email" id="email" placeholder="Email*" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>">
                               <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" name="mobile" id="mobile" placeholder="Mobile No." class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mobile')); ?>">
                               <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="number" min='1' name="amount" id="amount" placeholder="Amount" class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('amount')); ?>">
                               <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" name="address" id="address" placeholder="Address" class="form-control" value="<?php echo e(old('address')); ?>">
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" name="city" id="city" placeholder="City" class="form-control" value="<?php echo e(old('city')); ?>">
                           </div>
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" name="state" id="state" placeholder="State" class="form-control" value="<?php echo e(old('state')); ?>">
                           </div>
                           
                           
                           <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                              <button class="theme-btn btn-style-one" type="submit"><span class="txt">Submit</span></button>
                           </div>
                           
                        </div>
                     </form>
                     
                     <!--End Contact Form -->
                  </div>
                </div>
            </div>
        </div>
    </section>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsrs/public_html/demo/resources/views/web/donate.blade.php ENDPATH**/ ?>