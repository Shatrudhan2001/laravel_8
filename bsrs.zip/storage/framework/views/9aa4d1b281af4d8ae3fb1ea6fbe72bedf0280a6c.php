
<?php $__env->startSection('main.container'); ?>
    <!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(url('web/images/background/2.jpg')); ?>)">
        <div class="auto-container">
            <h1>Our Events</h1>
            <ul class="page-breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li>Our Events</li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->


    <!-- About Section -->
    <section class="blog-section">
        <div class="auto-container">
            <!-- Sec Title -->
            <div class="sec-title centered">
                <div class="title">Update Activities and Events</div>
                <h2>Recent Events</h2>
                <div class="text">Dolore eu fugiat nulla pariatur excepteur sint occaecat cupidatat non
                    proident
                    <br> sunt in culpa qui officia deserunt mollit anim id est laborum.
                </div>
            </div>

            <div class="row clearfix">

                <!-- News Block -->
                <?php if(!empty($event_list)): ?>
                <?php $__currentLoopData = $event_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="news-block col-lg-4 col-md-6 col-sm-12">
                    <div class="inner-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                        <div class="image">
                            <a href="<?php echo e(url('events-details/'.$r->id)); ?>"><img src="<?php echo e(url('uploads/events/'.$r->image)); ?>" alt="" /></a>
                             <?php
                             $datetime = new DateTime($r->created_at);
                            ?>
                            <div class="post-date"> <?php echo e(strtoUpper($datetime->format('d F Y'))); ?></div>
                        </div>
                        <div class="lower-content">

                            <h4><a href="<?php echo e(url('events-details/'.$r->id)); ?>"><?php echo e($r->title); ?></a></h4>
                            <div class="text"><?php echo e(\Illuminate\Support\Str::limit(strip_tags($r->description, 20))); ?></div>
                            <a href="<?php echo e(url('events-details/'.$r->id)); ?>" class="read-more theme-btn">View More</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>


            </div>
        </div>
    </section>
    <!-- End About Section -->






    <!-- Call To Action Section Two -->
    <section class="call-to-action-section-two">
        <div class="auto-container">
            <div class="inner-container" style="background-image: url(<?php echo e(url('web/images/background/pattern-2.png')); ?>)">
                <h3>Feel free to contact us with any questions or concerns <br> you may have. We’ll always be happy
                    to assist.</h3>
                <ul>
                    <li><span class="icon flaticon-phone-call"></span>+91 9876543210</li>
                    <li><span class="icon flaticon-email-1"></span>info@bsrs.in</li>
                </ul>
            </div>
        </div>
    </section>
    <!-- End Call To Action Section Two -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsrs/public_html/resources/views/web/events.blade.php ENDPATH**/ ?>