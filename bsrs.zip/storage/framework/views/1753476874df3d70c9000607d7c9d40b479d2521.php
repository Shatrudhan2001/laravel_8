
<?php $__env->startSection('main.container'); ?>
  <section class="team-detail-section" style="margin-bottom: 200px;">
		<div class="auto-container">
			<div class="row clearfix" style="margin: 0 auto; width: 50%">
				 <?php if(session('status')): ?>
				 <?php 
				    echo '<script>
				        setTimeout(myfun1, 100);
                        function myfun1(){
                            $(".loaderGif").css("display", "block");
                        }
				 
				 </script>'; ?>
                 <div class = "alert alert-info text-center col-lg-6 offset-3 loaderGif" style="display: none;">
                 <b><?php echo e(session('status')); ?></b> 
                 </div>   
                <?php endif; ?>
                
                <h3 class="text-center formhide" style="background: #e5e5e5;"><?php echo e($title); ?></h3>
				<div class="content-column formhide">
				    
                    <form class="row g-3 mt-3" method="post" action= "<?php echo e(url('update-password')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <button type="submit" class="btn btn-primary shadow p-2 rounded mt-3" id="submitBtn">Send Request</button>
                    
                    </form>
				</div>
			</div>
			<div>
			    <center><img src="<?php echo e(url('public/loading.gif')); ?>" width="300" class="preloadergig" style="display: none;"></center>
			</div>
		</div>
	</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.member.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsrs/public_html/resources/views/web/member/change-password.blade.php ENDPATH**/ ?>