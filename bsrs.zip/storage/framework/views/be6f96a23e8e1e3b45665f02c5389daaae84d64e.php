<!-- Main Footer -->
<footer class="main-footer margin-top">
    <div class="icon-one" style="background-image: url(web/images/icons/icon-1.png)"></div>
   
    <div class="footer-bottom">
        <div class="auto-container">
            <div class="clearfix">

                <div class="pull-left">
                    <div class="copyright">Copyrights &copy; 2022 Bhavsagar Residential Society All Rights
                        Reserved.</div>
                </div>
                <div class="pull-right">
                    <ul class="footer-nav">
                        <li><a href="#">Powerd by :- </a></li>
                        <li><a href="#">Indowebtech.com</a></li>

                    </ul>
                </div>

            </div>
        </div>
    </div>
</footer>

</div>
<div class="scroll-to-tops scroll-to-target" data-bs-target="html"><span class="fa fa-angle-up"></span></div>

<script src="<?php echo e(url('web/js/jquery.js')); ?>"></script>

<script src="<?php echo e(url('web/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(url('web/js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
<script src="<?php echo e(url('web/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(url('web/js/jquery.fancybox.js')); ?>"></script>
<script src="<?php echo e(url('web/js/appear.js')); ?>"></script>
<script src="<?php echo e(url('web/js/nav-tool.js')); ?>"></script>
<script src="<?php echo e(url('web/js/mixitup.js')); ?>"></script>
<script src="<?php echo e(url('web/js/owl.js')); ?>"></script>
<script src="<?php echo e(url('web/js/wow.js')); ?>"></script>
<script src="<?php echo e(url('web/js/isotope.js')); ?>"></script>
<script src="<?php echo e(url('web/js/vivus.min.js')); ?>"></script>
<script src="<?php echo e(url('web/js/jquery-ui.js')); ?>"></script>
<script src="<?php echo e(url('web/js/script.js')); ?>"></script>
<script src="<?php echo e(url('web/js/color-settings.js')); ?>"></script>
<script src="<?php echo e(url('web/js/jquery.validate.min.js')); ?>"></script>

</body>

</html>
<script>
$(document).ready(function(){
    $("#formData").validate({
        rules: {
        name: "required",
        email: "required",
        phone: "required",
        },
        
        messages: {
        name: "Please enter your firstname",
        email: "Please enter email address",
        phone: "Please enter your mobile number"
        },
        submitHandler: function(form) {
        form.submit();
        }
    });

});
</script><?php /**PATH D:\laravel8\projects\bsrs\resources\views/web/member/layouts/footer.blade.php ENDPATH**/ ?>