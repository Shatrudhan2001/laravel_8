
<?php $__env->startSection('main.container'); ?>
    <!--Page Title-->
    <section class="page-title" style="background-image:url(<?php echo e(url('web/images/background/2.jpg')); ?>)">
        <div class="auto-container">
            <h1><?php echo e($title); ?></h1>
            <ul class="page-breadcrumb">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><?php echo e($title); ?></li>
            </ul>
        </div>
    </section>
    <!--End Page Title-->
   <section class="about-section">
       
        <div class="auto-container">
            <div class="row clearfix">
                <div class="col-lg-8 col-md-12 col-sm-12">
                   <div class="faq-form">
                     
                     <!-- Contact Form -->
                    <?php if(session('status')): ?>
                        <div class="alert alert-success text-center">
                            <b><?php echo e(session('status')); ?></b>
                        </div>
                     <?php endif; ?>
                     <form method="post" action="<?php echo e(url('SaveEnquiry')); ?>" id="formData">
                     <?php echo csrf_field(); ?>
                        <div class="row clearfix">
                        
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" id="name" name="name" placeholder="Your Name*" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('name')); ?>">
                              <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="email" name="email" id="email" placeholder="Email*" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('email')); ?>">
                               <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" name="mobile" id="mobile" placeholder="Mobile No." class="form-control <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('mobile')); ?>">
                               <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="text-danger mt-1 mb-1"><?php echo e($message); ?></div>
                              <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                           </div>
                           
                           <div class="col-lg-6 col-md-6 col-sm-12 form-group">
                              <input type="text" name="address" id="address" placeholder="Address" value="<?php echo e(old('address')); ?>">
                           </div>
                           
                           
                           <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                              <textarea name="message" id="message" placeholder="Message"><?php echo e(old('message')); ?></textarea>
                           </div>
                           
                           <div class="col-lg-12 col-md-12 col-sm-12 form-group">
                              <button class="theme-btn btn-style-one" type="submit"><span class="txt">Submit</span></button>
                           </div>
                           
                        </div>
                     </form>
                     
                     <!--End Contact Form -->
                  </div>
                </div>

                <!-- Content Column -->
                <div class="content-column col-lg-4 col-md-12 col-sm-12">
                    <aside class="sidebar sticky-top">
                         <div class="sidebar-widget category-widget">
                            <div class="widget-content">
                                <div class="sidebar-title">
                                <h5>Contact us</h5>
                                </div>

                                <ul class="cat-list">
                                <li><a href="#">+91 9632587414</a></li>
                                <li><a href="#">infogsj@gmai.com</a></li>
                                
                                </ul>
                            </div>
                        </div>  
                    </aside>
                </div>
            </div>
        </div>
    </section>
     <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d55984.327868542445!2d77.11190332765504!3d28.7189336005275!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d0142b26feebf%3A0xa2c1e84000b80b9f!2sBluemaps%20Infratel%20Pvt%20Ltd.!5e0!3m2!1sen!2sin!4v1640626071097!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bsrs/public_html/demo/resources/views/web/contact.blade.php ENDPATH**/ ?>